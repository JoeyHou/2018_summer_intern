The website for this project is: http://www.gd.xinhuanet.com/gdstatics/zt18/xiaoshu12/
  
(Open in "inspect" mode and click "toggle device tool" to mobile phone mode)
